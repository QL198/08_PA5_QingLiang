﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    public float Coin = 4;
    public Text Txt_Coin;
  

    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = this.GetComponent<Rigidbody>();
        Txt_Coin.text = "Colled Coin : " + Coin;
    }

    // Update is called once per frame
    void Update()
    {
        FixedUpdate();
    }

    private void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
          PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("GameLose");
        }
        
        if(collision.gameObject.tag == "Coin")
        {
           
            if (Coin <= 1)
            {
                SceneManager.LoadScene("GameWin");
            }
            else
            {
                Coin -= 1;
                Destroy(collision.gameObject);
                Txt_Coin.text = "Collected Coin : " + Coin;
            }
            

        }
    }
}
